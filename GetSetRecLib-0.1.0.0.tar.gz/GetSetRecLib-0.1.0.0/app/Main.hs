module Main where



main :: IO ()
main = print 1
